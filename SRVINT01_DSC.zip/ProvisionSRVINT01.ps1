﻿Configuration SRVINT01Cfg {

    Import-DscResource -ModuleName PsDesiredStateConfiguration

    Node 'localhost' {

        # The first resource block ensures that the ADDSTools are   enabled.
        WindowsFeature RSAT-ADDS {
            Ensure = "Present"
            Name   = "RSAT-ADDS"
        }



    }
}
